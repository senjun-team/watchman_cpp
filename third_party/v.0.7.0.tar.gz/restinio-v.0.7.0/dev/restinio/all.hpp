/*
	restinio
*/

/*!
 * @file
 * @brief Include all necessary core header files in one.
 *
 * @deprecated Use `restinio/core.hpp` instead
 */

#include <restinio/core.hpp>

